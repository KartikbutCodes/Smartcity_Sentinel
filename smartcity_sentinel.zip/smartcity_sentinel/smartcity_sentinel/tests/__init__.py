"""Core unit tests."""
