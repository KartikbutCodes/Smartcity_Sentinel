"""Optional FastAPI service."""
