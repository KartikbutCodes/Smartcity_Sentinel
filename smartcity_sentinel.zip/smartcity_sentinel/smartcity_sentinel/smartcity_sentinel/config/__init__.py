"""Application configuration."""
