"""Synthetic, reproducible local data."""
